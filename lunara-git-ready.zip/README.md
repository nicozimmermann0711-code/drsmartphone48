# 🌙 Lunara

Premium E-Commerce Shop für Intimwäsche – mit Fokus auf Privatsphäre.

## Features

- **Zero Tracking**: Keine Analytics, keine Third-Party-Cookies
- **Lokale Datenspeicherung**: Warenkorb & Wunschliste im Browser
- **Diskret**: Neutrale Verpackung, externe Zahlungsabwicklung
- **PWA**: Installierbar, offline-fähig
- **Responsive**: Mobile-first Design

## Tech Stack

- Vanilla JavaScript (ES6 Modules)
- CSS Custom Properties
- localStorage API
- Service Worker für Offline-Support

## Struktur

```
├── index.html          # Landing Page
├── shop.html           # Produktübersicht mit Filtern
├── product.html        # Produktdetails
├── cart.html           # Warenkorb
├── checkout.html       # Kasse
├── account.html        # Konto & Einstellungen
├── assets/
│   ├── css/styles.css  # Komplettes Styling
│   ├── js/             # Module (config, utils, main, shop, product, cart, checkout, account, newsletter, pwa)
│   └── img/            # SVG Bilder
├── sw.js               # Service Worker
└── manifest.webmanifest
```

## Konfiguration

Bearbeite `assets/js/config.js` für:
- Produkte & Bundles
- Gutscheincodes
- Versandkosten
- Payment URLs (Stripe/PayPal)

## Deployment

1. Repository zu GitHub pushen
2. Settings → Pages → Source: main branch
3. Domain konfigurieren (optional)

## Version

1.0.1

---

Made with 🌙 by [NobleFrame](https://nobleframe.de)
