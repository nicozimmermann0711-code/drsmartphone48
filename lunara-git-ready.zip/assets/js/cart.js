/**
 * LUNARA Cart v1.0.1
 */
import { CONFIG } from './config.js';
import { formatCurrency, createElement, getProductById, showToast, safeStorage } from './utils.js';
import { getCart, updateCartQty, removeFromCart, clearCart, updateShippingProgress } from './main.js';

let appliedCoupon = null;

function initCart() {
  renderCart();
  initCoupon();
}

function renderCart() {
  const cart = getCart();
  const emptyEl = document.getElementById('cart-empty');
  const contentEl = document.getElementById('cart-content');
  const itemsEl = document.getElementById('cart-items');
  const summaryEl = document.getElementById('cart-summary');

  if (cart.length === 0) {
    emptyEl.hidden = false;
    contentEl.hidden = true;
    return;
  }

  emptyEl.hidden = true;
  contentEl.hidden = false;
  itemsEl.innerHTML = '';

  let subtotal = 0;
  cart.forEach(item => {
    const product = getProductById(item.productId);
    if (!product) return;
    const variant = product.variants.find(v => v.id === item.variantId);
    const itemTotal = product.price * item.qty;
    subtotal += itemTotal;

    const row = createElement('div', { class: 'cart-item' });
    row.innerHTML = `
      <img src="${product.images[0]}" alt="${product.name}" class="cart-item__image">
      <div class="cart-item__info">
        <a href="product.html?id=${product.id}" class="cart-item__name">${product.name}</a>
        <span class="cart-item__variant">${variant?.name || ''}</span>
        <span class="cart-item__price">${formatCurrency(product.price)}</span>
      </div>
      <div class="cart-item__quantity">
        <button type="button" class="qty-btn qty-minus">−</button>
        <input type="number" value="${item.qty}" min="1" max="${variant?.stock || 99}" class="qty-input">
        <button type="button" class="qty-btn qty-plus">+</button>
      </div>
      <span class="cart-item__total">${formatCurrency(itemTotal)}</span>
      <button type="button" class="cart-item__remove" aria-label="Entfernen">✕</button>
    `;

    row.querySelector('.qty-minus').addEventListener('click', () => { updateCartQty(item.productId, item.variantId, item.qty - 1); renderCart(); });
    row.querySelector('.qty-plus').addEventListener('click', () => { updateCartQty(item.productId, item.variantId, item.qty + 1); renderCart(); });
    row.querySelector('.qty-input').addEventListener('change', e => { updateCartQty(item.productId, item.variantId, parseInt(e.target.value) || 1); renderCart(); });
    row.querySelector('.cart-item__remove').addEventListener('click', () => { removeFromCart(item.productId, item.variantId); renderCart(); });

    itemsEl.appendChild(row);
  });

  // Summary
  let discount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.type === 'percent') discount = subtotal * (appliedCoupon.value / 100);
    else if (appliedCoupon.type === 'fixed') discount = appliedCoupon.value;
  }

  const afterDiscount = subtotal - discount;
  const shipping = (appliedCoupon?.type === 'freeShipping' || afterDiscount >= CONFIG.FREE_SHIPPING_THRESHOLD) ? 0 : CONFIG.SHIPPING_COST;
  const total = afterDiscount + shipping;

  summaryEl.innerHTML = `
    <div class="summary-row"><span>Zwischensumme</span><span>${formatCurrency(subtotal)}</span></div>
    ${discount > 0 ? `<div class="summary-row summary-row--discount"><span>Rabatt</span><span>-${formatCurrency(discount)}</span></div>` : ''}
    <div class="summary-row"><span>Versand</span><span>${shipping === 0 ? 'Kostenlos' : formatCurrency(shipping)}</span></div>
    <div class="summary-row summary-row--total"><span>Gesamt</span><span>${formatCurrency(total)}</span></div>
    <a href="checkout.html" class="btn btn--primary btn--full" style="margin-top: var(--space-4);">Zur Kasse</a>
  `;

  updateShippingProgress();
}

function initCoupon() {
  const form = document.getElementById('coupon-form');
  const input = document.getElementById('coupon-input');
  const applyBtn = document.getElementById('coupon-apply');
  const removeBtn = document.getElementById('coupon-remove');
  const appliedEl = document.getElementById('coupon-applied');
  const codeEl = document.getElementById('coupon-applied-code');
  const errorEl = document.getElementById('coupon-error');

  form?.addEventListener('submit', e => {
    e.preventDefault();
    const code = input.value.trim().toUpperCase();
    if (!code) return;

    const coupon = CONFIG.COUPONS[code];
    if (!coupon) { errorEl.textContent = 'Ungültiger Gutscheincode'; errorEl.hidden = false; return; }

    const cart = getCart();
    const subtotal = cart.reduce((s, i) => { const p = getProductById(i.productId); return s + (p ? p.price * i.qty : 0); }, 0);
    if (coupon.minOrder > 0 && subtotal < coupon.minOrder) { errorEl.textContent = `Mindestbestellwert: ${formatCurrency(coupon.minOrder)}`; errorEl.hidden = false; return; }

    appliedCoupon = coupon;
    safeStorage('coupon', code);
    input.disabled = true;
    applyBtn.hidden = true;
    removeBtn.hidden = false;
    appliedEl.hidden = false;
    codeEl.textContent = code;
    errorEl.hidden = true;
    showToast('Gutschein angewendet!', 'success');
    renderCart();
  });

  removeBtn?.addEventListener('click', () => {
    appliedCoupon = null;
    safeStorage('coupon', null, true);
    input.disabled = false;
    input.value = '';
    applyBtn.hidden = false;
    removeBtn.hidden = true;
    appliedEl.hidden = true;
    renderCart();
  });

  // Restore saved coupon
  const saved = safeStorage('coupon');
  if (saved && CONFIG.COUPONS[saved]) {
    input.value = saved;
    form.dispatchEvent(new Event('submit'));
  }
}

document.addEventListener('DOMContentLoaded', initCart);
