/**
 * LUNARA PWA v1.0.1
 */
import { CONFIG } from './config.js';

let deferredPrompt = null;

async function initPWA() {
  // Register Service Worker
  if ('serviceWorker' in navigator) {
    try {
      const reg = await navigator.serviceWorker.register('/sw.js');
      reg.addEventListener('updatefound', () => {
        const newWorker = reg.installing;
        newWorker?.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            showUpdateNotification();
          }
        });
      });
    } catch (err) { console.log('SW registration failed:', err); }
  }

  // Install prompt
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    showInstallPrompt();
  });
}

function showInstallPrompt() {
  const container = document.getElementById('pwa-install');
  if (!container) return;
  container.hidden = false;
  container.querySelector('.pwa-install__btn')?.addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    deferredPrompt = null;
    container.hidden = true;
  });
  container.querySelector('.pwa-install__dismiss')?.addEventListener('click', () => container.hidden = true);
}

function showUpdateNotification() {
  const toast = document.createElement('div');
  toast.className = 'update-toast';
  toast.innerHTML = `<span>Neue Version verfügbar!</span><button class="btn btn--small">Aktualisieren</button>`;
  toast.querySelector('button').addEventListener('click', () => location.reload());
  document.body.appendChild(toast);
}

document.addEventListener('DOMContentLoaded', initPWA);
