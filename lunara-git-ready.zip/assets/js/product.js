/**
 * LUNARA Product Detail v1.0.1
 */
import { CONFIG } from './config.js';
import { formatCurrency, createElement, getProductById, getVariantById } from './utils.js';
import { addToCart, toggleWishlist, isInWishlist, addRecentlyViewed } from './main.js';

let currentProduct = null;
let selectedVariant = null;
let quantity = 1;

function initProduct() {
  const params = new URLSearchParams(window.location.search);
  const productId = params.get('id');
  if (!productId) { window.location.href = 'shop.html'; return; }
  
  currentProduct = getProductById(productId);
  if (!currentProduct) { window.location.href = '404.html'; return; }
  
  addRecentlyViewed(productId);
  renderProduct();
  initTabs();
  initQuantity();
  initActions();
}

function renderProduct() {
  document.title = `${currentProduct.name} | Lunara`;
  document.getElementById('breadcrumb-product').textContent = currentProduct.name;
  document.getElementById('product-name').textContent = currentProduct.name;
  document.getElementById('product-category').textContent = currentProduct.category;
  document.getElementById('product-description').textContent = currentProduct.description;
  document.getElementById('tab-description-content').textContent = currentProduct.description;

  // Badges
  const badgesEl = document.getElementById('product-badges');
  if (currentProduct.isNew) badgesEl.appendChild(createElement('span', { class: 'badge badge--new' }, ['Neu']));

  // Rating
  const ratingEl = document.getElementById('product-rating');
  ratingEl.innerHTML = `<span class="stars">${'★'.repeat(Math.floor(currentProduct.rating))}${'☆'.repeat(5 - Math.floor(currentProduct.rating))}</span> <span>(${currentProduct.reviewsCount} Bewertungen)</span>`;

  // Price
  document.getElementById('product-price').innerHTML = `<span class="product-price">${formatCurrency(currentProduct.price)}</span>`;

  // Tags
  const tagsEl = document.getElementById('product-tags');
  currentProduct.tags.forEach(t => tagsEl.appendChild(createElement('span', { class: 'tag' }, [t])));

  // Gallery
  const gallery = document.getElementById('product-gallery');
  currentProduct.images.forEach((src, i) => {
    const img = createElement('img', { src, alt: currentProduct.name, class: i === 0 ? 'product-gallery__main' : 'product-gallery__thumb' });
    gallery.appendChild(img);
  });

  // Variants
  renderVariants();
  
  // Wishlist
  const wishBtn = document.getElementById('wishlist-toggle');
  if (wishBtn) {
    updateWishlistButton();
    wishBtn.addEventListener('click', () => { toggleWishlist(currentProduct.id); updateWishlistButton(); });
  }

  // Related
  renderRelated();
}

function renderVariants() {
  const container = document.getElementById('variant-selector');
  container.innerHTML = '<label class="form-label">Größe wählen:</label><div class="variant-options"></div>';
  const opts = container.querySelector('.variant-options');
  
  currentProduct.variants.forEach((v, i) => {
    const btn = createElement('button', { class: 'variant-btn' + (v.stock === 0 ? ' variant-btn--soldout' : ''), type: 'button', disabled: v.stock === 0 }, [v.name]);
    btn.addEventListener('click', () => selectVariant(v.id));
    if (i === 0 && v.stock > 0) { btn.classList.add('variant-btn--selected'); selectedVariant = v; }
    opts.appendChild(btn);
  });
  
  if (!selectedVariant) selectedVariant = currentProduct.variants.find(v => v.stock > 0);
  updateStock();
}

function selectVariant(variantId) {
  selectedVariant = getVariantById(currentProduct, variantId);
  document.querySelectorAll('.variant-btn').forEach(b => b.classList.remove('variant-btn--selected'));
  event.target.classList.add('variant-btn--selected');
  updateStock();
}

function updateStock() {
  const stockEl = document.getElementById('product-stock');
  const addBtn = document.getElementById('add-to-cart');
  const buyBtn = document.getElementById('buy-now');
  
  if (!selectedVariant || selectedVariant.stock === 0) {
    stockEl.innerHTML = '<span class="stock stock--out">Ausverkauft</span>';
    addBtn.disabled = true;
    buyBtn.disabled = true;
  } else if (selectedVariant.stock <= 3) {
    stockEl.innerHTML = `<span class="stock stock--low">Nur noch ${selectedVariant.stock} auf Lager</span>`;
    addBtn.disabled = false;
    buyBtn.disabled = false;
  } else {
    stockEl.innerHTML = '<span class="stock stock--in">Auf Lager</span>';
    addBtn.disabled = false;
    buyBtn.disabled = false;
  }
}

function initQuantity() {
  const input = document.getElementById('quantity-input');
  document.getElementById('quantity-minus')?.addEventListener('click', () => { if (quantity > 1) { quantity--; input.value = quantity; } });
  document.getElementById('quantity-plus')?.addEventListener('click', () => { if (selectedVariant && quantity < selectedVariant.stock) { quantity++; input.value = quantity; } });
  input?.addEventListener('change', e => { quantity = Math.max(1, Math.min(parseInt(e.target.value) || 1, selectedVariant?.stock || 99)); input.value = quantity; });
}

function initActions() {
  document.getElementById('add-to-cart')?.addEventListener('click', () => {
    if (selectedVariant) addToCart(currentProduct.id, selectedVariant.id, quantity);
  });
  document.getElementById('buy-now')?.addEventListener('click', () => {
    if (selectedVariant && addToCart(currentProduct.id, selectedVariant.id, quantity)) {
      window.location.href = 'checkout.html';
    }
  });
}

function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => { b.classList.remove('tab-btn--active'); b.setAttribute('aria-selected', 'false'); });
      document.querySelectorAll('.tab-panel').forEach(p => p.hidden = true);
      btn.classList.add('tab-btn--active');
      btn.setAttribute('aria-selected', 'true');
      document.getElementById(btn.dataset.tab).hidden = false;
    });
  });
}

function updateWishlistButton() {
  const btn = document.getElementById('wishlist-toggle');
  const inWish = isInWishlist(currentProduct.id);
  btn.textContent = inWish ? '♥ Auf Wunschliste' : '♡ Zur Wunschliste';
  btn.classList.toggle('wishlist-btn--active', inWish);
}

function renderRelated() {
  const container = document.querySelector('.related-grid');
  if (!container) return;
  const related = CONFIG.PRODUCTS.filter(p => p.id !== currentProduct.id && p.category === currentProduct.category).slice(0, 4);
  related.forEach(p => {
    const card = createElement('a', { href: `product.html?id=${p.id}`, class: 'related-card' });
    card.innerHTML = `<img src="${p.images[0]}" alt="${p.name}" loading="lazy"><h4>${p.name}</h4><span>${formatCurrency(p.price)}</span>`;
    container.appendChild(card);
  });
}

document.addEventListener('DOMContentLoaded', initProduct);
