/**
 * LUNARA Utilities v1.0.1
 */
import { CONFIG } from './config.js';

export function formatCurrency(amount) {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(amount);
}

export function createElement(tag, attrs = {}, children = []) {
  const el = document.createElement(tag);
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === 'class') el.className = v;
    else if (k.startsWith('data-')) el.setAttribute(k, v);
    else el[k] = v;
  });
  children.forEach(c => {
    if (typeof c === 'string') el.appendChild(document.createTextNode(c));
    else if (c) el.appendChild(c);
  });
  return el;
}

export function getProductById(id) {
  return CONFIG.PRODUCTS.find(p => p.id === id) || null;
}

export function getBundleById(id) {
  return CONFIG.BUNDLES.find(b => b.id === id) || null;
}

export function getVariantById(product, variantId) {
  return product?.variants?.find(v => v.id === variantId) || null;
}

export function safeStorage(key, value = undefined, remove = false) {
  const k = CONFIG.STORE_KEY_PREFIX + key;
  try {
    if (remove) { localStorage.removeItem(k); return null; }
    if (value === undefined) {
      const v = localStorage.getItem(k);
      return v ? JSON.parse(v) : null;
    }
    localStorage.setItem(k, JSON.stringify(value));
    return value;
  } catch { return null; }
}

export function debounce(fn, ms = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

export function sanitizeText(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

export function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validatePLZ(plz) {
  return /^[0-9]{5}$/.test(plz);
}

export function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

export function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = createElement('div', { class: `toast toast--${type}` }, [message]);
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('toast--visible'));
  setTimeout(() => {
    toast.classList.remove('toast--visible');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}
