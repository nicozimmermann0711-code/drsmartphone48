// LUNARA Security utilities v1.0.1
// This file is a placeholder for future security enhancements
export function sanitize(input) {
  const div = document.createElement('div');
  div.textContent = input;
  return div.innerHTML;
}
