/**
 * LUNARA Account v1.0.1
 */
import { CONFIG } from './config.js';
import { formatCurrency, getProductById, safeStorage, showToast, createElement } from './utils.js';
import { getWishlist, toggleWishlist } from './main.js';

function initAccount() {
  renderOrders();
  renderWishlist();
  initPreferences();
  initDataManagement();
}

function renderOrders() {
  const container = document.getElementById('orders-list');
  const orders = safeStorage('orders') || [];
  
  if (orders.length === 0) {
    container.innerHTML = '<p class="empty-state">Noch keine Bestellungen</p>';
    return;
  }

  container.innerHTML = orders.map(order => `
    <div class="order-card">
      <div class="order-header">
        <span class="order-id">#${order.id}</span>
        <span class="order-date">${new Date(order.date).toLocaleDateString('de-DE')}</span>
        <span class="order-status order-status--${order.status}">${order.status}</span>
      </div>
      <div class="order-total">${formatCurrency(order.total)}</div>
    </div>
  `).join('');
}

function renderWishlist() {
  const container = document.getElementById('wishlist-grid');
  const wishlist = getWishlist();
  
  if (wishlist.length === 0) {
    container.innerHTML = '<p class="empty-state">Deine Wunschliste ist leer</p>';
    return;
  }

  container.innerHTML = '';
  wishlist.forEach(id => {
    const p = getProductById(id);
    if (!p) return;
    const card = createElement('div', { class: 'wishlist-card' });
    card.innerHTML = `
      <a href="product.html?id=${p.id}"><img src="${p.images[0]}" alt="${p.name}"></a>
      <div class="wishlist-card__info">
        <a href="product.html?id=${p.id}">${p.name}</a>
        <span>${formatCurrency(p.price)}</span>
      </div>
      <button type="button" class="wishlist-card__remove">✕</button>
    `;
    card.querySelector('.wishlist-card__remove').addEventListener('click', () => { toggleWishlist(id); renderWishlist(); });
    container.appendChild(card);
  });
}

function initPreferences() {
  // Theme
  const theme = safeStorage('theme') || 'dark';
  document.querySelector(`input[name="theme"][value="${theme}"]`)?.setAttribute('checked', '');
  document.querySelectorAll('input[name="theme"]').forEach(r => {
    r.addEventListener('change', e => {
      document.documentElement.dataset.theme = e.target.value;
      safeStorage('theme', e.target.value);
    });
  });

  // Notifications
  const notif = document.getElementById('notifications-toggle');
  notif.checked = safeStorage('notifications') || false;
  notif?.addEventListener('change', e => safeStorage('notifications', e.target.checked));
}

function initDataManagement() {
  document.getElementById('export-data')?.addEventListener('click', () => {
    const data = {};
    Object.keys(localStorage).forEach(k => {
      if (k.startsWith(CONFIG.STORE_KEY_PREFIX)) data[k] = localStorage.getItem(k);
    });
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `lunara-backup-${Date.now()}.json`;
    a.click();
    showToast('Daten exportiert', 'success');
  });

  document.getElementById('import-data')?.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        Object.entries(data).forEach(([k, v]) => localStorage.setItem(k, v));
        showToast('Daten importiert', 'success');
        location.reload();
      } catch { showToast('Ungültige Datei', 'error'); }
    };
    reader.readAsText(file);
  });

  document.getElementById('clear-data')?.addEventListener('click', () => {
    if (!confirm('Wirklich alle Daten löschen?')) return;
    Object.keys(localStorage).forEach(k => {
      if (k.startsWith(CONFIG.STORE_KEY_PREFIX)) localStorage.removeItem(k);
    });
    showToast('Alle Daten gelöscht', 'success');
    location.reload();
  });
}

document.addEventListener('DOMContentLoaded', initAccount);
