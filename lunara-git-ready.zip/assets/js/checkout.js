/**
 * LUNARA Checkout v1.0.1
 */
import { CONFIG } from './config.js';
import { formatCurrency, getProductById, validateEmail, validatePLZ, showToast, safeStorage, generateId } from './utils.js';
import { getCart, clearCart } from './main.js';

function initCheckout() {
  const cart = getCart();
  if (cart.length === 0) { window.location.href = 'cart.html'; return; }
  renderSummary();
  initForm();
  initPayment();
}

function renderSummary() {
  const cart = getCart();
  const container = document.getElementById('checkout-summary');
  let subtotal = 0;
  let html = '<h3>Bestellübersicht</h3><div class="checkout-items">';
  
  cart.forEach(item => {
    const p = getProductById(item.productId);
    if (!p) return;
    const v = p.variants.find(v => v.id === item.variantId);
    const total = p.price * item.qty;
    subtotal += total;
    html += `<div class="checkout-item"><span>${p.name} (${v?.name}) × ${item.qty}</span><span>${formatCurrency(total)}</span></div>`;
  });

  const couponCode = safeStorage('coupon');
  const coupon = couponCode ? CONFIG.COUPONS[couponCode] : null;
  let discount = 0;
  if (coupon?.type === 'percent') discount = subtotal * (coupon.value / 100);
  else if (coupon?.type === 'fixed') discount = coupon.value;

  const afterDiscount = subtotal - discount;
  const shipping = (coupon?.type === 'freeShipping' || afterDiscount >= CONFIG.FREE_SHIPPING_THRESHOLD) ? 0 : CONFIG.SHIPPING_COST;
  const total = afterDiscount + shipping;

  html += '</div>';
  html += `<div class="checkout-totals">`;
  html += `<div class="summary-row"><span>Zwischensumme</span><span>${formatCurrency(subtotal)}</span></div>`;
  if (discount > 0) html += `<div class="summary-row"><span>Rabatt</span><span>-${formatCurrency(discount)}</span></div>`;
  html += `<div class="summary-row"><span>Versand</span><span>${shipping === 0 ? 'Kostenlos' : formatCurrency(shipping)}</span></div>`;
  html += `<div class="summary-row summary-row--total"><span>Gesamt</span><span>${formatCurrency(total)}</span></div>`;
  html += `</div>`;
  container.innerHTML = html;
}

function initForm() {
  const form = document.getElementById('checkout-form');
  const step1 = document.getElementById('step-form');
  const step2 = document.getElementById('step-payment');

  form?.addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const plz = document.getElementById('plz').value;
    const age = document.getElementById('age-confirm').checked;
    const terms = document.getElementById('terms-confirm').checked;

    if (!validateEmail(email)) { showToast('Bitte gültige E-Mail eingeben', 'error'); return; }
    if (!validatePLZ(plz)) { showToast('Bitte gültige PLZ eingeben (5 Ziffern)', 'error'); return; }
    if (!age) { showToast('Bitte Alter bestätigen', 'error'); return; }
    if (!terms) { showToast('Bitte AGB akzeptieren', 'error'); return; }

    step1.hidden = true;
    step2.hidden = false;
  });
}

function initPayment() {
  document.getElementById('pay-stripe')?.addEventListener('click', () => processPayment('stripe'));
  document.getElementById('pay-paypal')?.addEventListener('click', () => processPayment('paypal'));
}

function processPayment(method) {
  const order = {
    id: generateId(),
    items: getCart(),
    total: calculateTotal(),
    method,
    date: new Date().toISOString(),
    status: 'pending'
  };

  // Save order
  const orders = safeStorage('orders') || [];
  orders.push(order);
  safeStorage('orders', orders);
  safeStorage('coupon', null, true);
  clearCart();

  // Redirect to payment
  const url = CONFIG.PAYMENT_URLS[method];
  if (url && !url.includes('placeholder')) {
    window.open(url, '_blank');
  }
  window.location.href = `confirmation.html?order=${order.id}`;
}

function calculateTotal() {
  const cart = getCart();
  let subtotal = cart.reduce((s, i) => { const p = getProductById(i.productId); return s + (p ? p.price * i.qty : 0); }, 0);
  const couponCode = safeStorage('coupon');
  const coupon = couponCode ? CONFIG.COUPONS[couponCode] : null;
  let discount = 0;
  if (coupon?.type === 'percent') discount = subtotal * (coupon.value / 100);
  else if (coupon?.type === 'fixed') discount = coupon.value;
  const afterDiscount = subtotal - discount;
  const shipping = (coupon?.type === 'freeShipping' || afterDiscount >= CONFIG.FREE_SHIPPING_THRESHOLD) ? 0 : CONFIG.SHIPPING_COST;
  return afterDiscount + shipping;
}

document.addEventListener('DOMContentLoaded', initCheckout);
