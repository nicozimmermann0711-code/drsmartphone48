/**
 * LUNARA Shop v1.0.1
 */
import { CONFIG } from './config.js';
import { formatCurrency, createElement, debounce, getProductById } from './utils.js';
import { addToCart, toggleWishlist, isInWishlist } from './main.js';

let filteredProducts = [...CONFIG.PRODUCTS];
let currentFilters = { category: 'all', tags: [], priceMin: 0, priceMax: Infinity, isNew: false, inStock: false, hasBundle: false, search: '' };
let currentSort = 'popularity';

function initShop() {
  initFilters();
  initSearch();
  initSort();
  applyURLParams();
  renderProducts();
}

function initFilters() {
  const catSelect = document.getElementById('filter-category');
  if (catSelect) {
    catSelect.innerHTML = '<option value="all">Alle Kategorien</option>';
    CONFIG.CATEGORIES.forEach(c => {
      catSelect.innerHTML += `<option value="${c}">${c}</option>`;
    });
    catSelect.addEventListener('change', () => { currentFilters.category = catSelect.value; applyFilters(); });
  }

  const tagsContainer = document.getElementById('filter-tags');
  if (tagsContainer) {
    CONFIG.TAGS.forEach(tag => {
      const btn = createElement('button', { class: 'filter-tag', type: 'button' }, [tag]);
      btn.addEventListener('click', () => {
        btn.classList.toggle('filter-tag--active');
        if (currentFilters.tags.includes(tag)) currentFilters.tags = currentFilters.tags.filter(t => t !== tag);
        else currentFilters.tags.push(tag);
        applyFilters();
      });
      tagsContainer.appendChild(btn);
    });
  }

  document.getElementById('filter-price-min')?.addEventListener('input', debounce(e => { currentFilters.priceMin = parseFloat(e.target.value) || 0; applyFilters(); }));
  document.getElementById('filter-price-max')?.addEventListener('input', debounce(e => { currentFilters.priceMax = parseFloat(e.target.value) || Infinity; applyFilters(); }));
  document.getElementById('filter-new')?.addEventListener('change', e => { currentFilters.isNew = e.target.checked; applyFilters(); });
  document.getElementById('filter-stock')?.addEventListener('change', e => { currentFilters.inStock = e.target.checked; applyFilters(); });
  document.getElementById('filter-bundle')?.addEventListener('change', e => { currentFilters.hasBundle = e.target.checked; applyFilters(); });
  document.getElementById('reset-filters')?.addEventListener('click', resetFilters);
}

function initSearch() {
  const input = document.querySelector('.shop-search__input');
  const clear = document.querySelector('.shop-search__clear');
  if (!input) return;
  input.addEventListener('input', debounce(e => {
    currentFilters.search = e.target.value.toLowerCase();
    clear.hidden = !currentFilters.search;
    applyFilters();
  }));
  clear?.addEventListener('click', () => { input.value = ''; currentFilters.search = ''; clear.hidden = true; applyFilters(); });
}

function initSort() {
  document.getElementById('sort-select')?.addEventListener('change', e => { currentSort = e.target.value; applyFilters(); });
}

function applyURLParams() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('search')) { currentFilters.search = params.get('search').toLowerCase(); const input = document.querySelector('.shop-search__input'); if (input) input.value = params.get('search'); }
  if (params.get('category')) { currentFilters.category = params.get('category'); const sel = document.getElementById('filter-category'); if (sel) sel.value = params.get('category'); }
  if (params.get('isNew') === 'true') { currentFilters.isNew = true; const cb = document.getElementById('filter-new'); if (cb) cb.checked = true; }
  if (params.get('hasBundle') === 'true') { currentFilters.hasBundle = true; const cb = document.getElementById('filter-bundle'); if (cb) cb.checked = true; }
  if (params.get('sort')) { currentSort = params.get('sort'); const sel = document.getElementById('sort-select'); if (sel) sel.value = params.get('sort'); }
}

function resetFilters() {
  currentFilters = { category: 'all', tags: [], priceMin: 0, priceMax: Infinity, isNew: false, inStock: false, hasBundle: false, search: '' };
  document.getElementById('filter-category').value = 'all';
  document.querySelectorAll('.filter-tag--active').forEach(b => b.classList.remove('filter-tag--active'));
  document.getElementById('filter-price-min').value = '';
  document.getElementById('filter-price-max').value = '';
  document.getElementById('filter-new').checked = false;
  document.getElementById('filter-stock').checked = false;
  document.getElementById('filter-bundle').checked = false;
  document.querySelector('.shop-search__input').value = '';
  applyFilters();
}

function applyFilters() {
  filteredProducts = CONFIG.PRODUCTS.filter(p => {
    if (currentFilters.category !== 'all' && p.category !== currentFilters.category) return false;
    if (currentFilters.tags.length && !currentFilters.tags.some(t => p.tags.includes(t))) return false;
    if (p.price < currentFilters.priceMin || p.price > currentFilters.priceMax) return false;
    if (currentFilters.isNew && !p.isNew) return false;
    if (currentFilters.inStock && !p.variants.some(v => v.stock > 0)) return false;
    if (currentFilters.hasBundle && !CONFIG.BUNDLES.some(b => b.items.includes(p.id))) return false;
    if (currentFilters.search && !p.name.toLowerCase().includes(currentFilters.search) && !p.description.toLowerCase().includes(currentFilters.search)) return false;
    return true;
  });
  sortProducts();
  renderProducts();
}

function sortProducts() {
  filteredProducts.sort((a, b) => {
    switch (currentSort) {
      case 'price-asc': return a.price - b.price;
      case 'price-desc': return b.price - a.price;
      case 'newest': return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
      case 'rating': return b.rating - a.rating;
      default: return b.popularity - a.popularity;
    }
  });
}

function renderProducts() {
  const grid = document.getElementById('product-grid');
  const count = document.querySelector('.product-count');
  if (!grid) return;
  grid.innerHTML = '';
  count.textContent = `${filteredProducts.length} Produkt${filteredProducts.length !== 1 ? 'e' : ''}`;

  filteredProducts.forEach(product => {
    const card = createElement('article', { class: 'card product-card' });
    const imageWrapper = createElement('div', { class: 'card__image product-card__image-wrapper' });
    const img = createElement('img', { src: product.images[0], alt: product.name, width: '300', height: '300', loading: 'lazy' });
    imageWrapper.appendChild(img);

    const badges = createElement('div', { class: 'product-card__badges' });
    if (product.isNew) badges.appendChild(createElement('span', { class: 'badge badge--new' }, ['Neu']));
    if (badges.children.length) imageWrapper.appendChild(badges);

    const wishBtn = createElement('button', { class: 'product-card__wishlist' + (isInWishlist(product.id) ? ' product-card__wishlist--active' : ''), type: 'button' }, ['♡']);
    wishBtn.addEventListener('click', e => { e.preventDefault(); const active = toggleWishlist(product.id); wishBtn.classList.toggle('product-card__wishlist--active', active); wishBtn.textContent = active ? '♥' : '♡'; });
    imageWrapper.appendChild(wishBtn);
    card.appendChild(imageWrapper);

    const content = createElement('div', { class: 'card__content' });
    content.appendChild(createElement('span', { class: 'product-card__category' }, [product.category]));
    const titleLink = createElement('a', { href: `product.html?id=${product.id}`, class: 'product-card__title-link' });
    titleLink.appendChild(createElement('h3', { class: 'product-card__title' }, [product.name]));
    content.appendChild(titleLink);

    const rating = createElement('div', { class: 'product-card__rating' });
    rating.innerHTML = `<span class="stars">${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}</span> <span class="count">(${product.reviewsCount})</span>`;
    content.appendChild(rating);
    content.appendChild(createElement('div', { class: 'product-card__price' }, [formatCurrency(product.price)]));

    const addBtn = createElement('button', { class: 'btn btn--primary btn--full product-card__add', type: 'button' }, ['In den Warenkorb']);
    const hasStock = product.variants.some(v => v.stock > 0);
    if (!hasStock) { addBtn.disabled = true; addBtn.textContent = 'Ausverkauft'; }
    addBtn.addEventListener('click', () => { const variant = product.variants.find(v => v.stock > 0); if (variant) addToCart(product.id, variant.id, 1); });
    content.appendChild(addBtn);
    card.appendChild(content);
    grid.appendChild(card);
  });
}

document.addEventListener('DOMContentLoaded', initShop);
