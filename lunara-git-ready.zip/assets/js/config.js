/**
 * LUNARA Configuration v1.0.1
 */
export const CONFIG = {
  APP_VERSION: "1.0.1",
  BRAND_NAME: "Lunara",
  STORE_KEY_PREFIX: "lunara_",
  FREE_SHIPPING_THRESHOLD: 49,
  SHIPPING_COST: 4.90,
  MAX_RECENTLY_VIEWED: 8,
  NEWSLETTER_PROVIDER: null,
  NEWSLETTER_COOLDOWN: 10000,
  PAYMENT_URLS: {
    stripe: "https://buy.stripe.com/test_placeholder",
    paypal: "https://www.paypal.com/paypalme/placeholder"
  },
  CATEGORIES: ["Dessous", "Lingerie", "Accessoires", "Sets", "Pflege"],
  TAGS: ["Spitze", "Seide", "Baumwolle", "Schwarz", "Rot", "Nude", "Transparent"],
  PRODUCTS: [
    { id: "luna-lace-set", name: "Luna Lace Set", category: "Sets", description: "Elegantes zweiteiliges Set aus feiner französischer Spitze.", price: 89.00, images: ["assets/img/product-1.svg"], tags: ["Spitze", "Schwarz"], variants: [{ id: "s", name: "S", stock: 5, priceModifier: 0 }, { id: "m", name: "M", stock: 8, priceModifier: 0 }, { id: "l", name: "L", stock: 3, priceModifier: 0 }], rating: 4.8, reviewsCount: 124, isNew: true, popularity: 95 },
    { id: "midnight-silk-chemise", name: "Midnight Silk Chemise", category: "Lingerie", description: "Luxuriöses Nachthemd aus 100% Maulbeerseide.", price: 129.00, images: ["assets/img/product-2.svg"], tags: ["Seide", "Schwarz"], variants: [{ id: "s", name: "S", stock: 4, priceModifier: 0 }, { id: "m", name: "M", stock: 6, priceModifier: 0 }, { id: "l", name: "L", stock: 2, priceModifier: 0 }], rating: 4.9, reviewsCount: 89, isNew: false, popularity: 88 },
    { id: "rose-petal-bralette", name: "Rose Petal Bralette", category: "Dessous", description: "Zarte Bralette mit floralem Spitzenmuster.", price: 45.00, images: ["assets/img/product-3.svg"], tags: ["Spitze", "Nude"], variants: [{ id: "xs", name: "XS", stock: 7, priceModifier: 0 }, { id: "s", name: "S", stock: 12, priceModifier: 0 }, { id: "m", name: "M", stock: 10, priceModifier: 0 }, { id: "l", name: "L", stock: 5, priceModifier: 0 }], rating: 4.7, reviewsCount: 203, isNew: true, popularity: 92 },
    { id: "velvet-dreams-robe", name: "Velvet Dreams Robe", category: "Lingerie", description: "Samtiger Morgenmantel mit Satinbesatz.", price: 149.00, images: ["assets/img/product-4.svg"], tags: ["Schwarz", "Rot"], variants: [{ id: "s-m", name: "S/M", stock: 3, priceModifier: 0 }, { id: "l-xl", name: "L/XL", stock: 4, priceModifier: 0 }], rating: 4.6, reviewsCount: 67, isNew: false, popularity: 75 },
    { id: "celestial-bodysuit", name: "Celestial Bodysuit", category: "Dessous", description: "Atemberaubender Body mit Sternenmuster.", price: 79.00, images: ["assets/img/product-5.svg"], tags: ["Transparent", "Schwarz"], variants: [{ id: "s", name: "S", stock: 6, priceModifier: 0 }, { id: "m", name: "M", stock: 8, priceModifier: 0 }, { id: "l", name: "L", stock: 0, priceModifier: 0 }], rating: 4.8, reviewsCount: 156, isNew: true, popularity: 98 },
    { id: "pure-cotton-essentials", name: "Pure Cotton Essentials", category: "Dessous", description: "3er-Pack klassische Slips aus Bio-Baumwolle.", price: 35.00, images: ["assets/img/product-6.svg"], tags: ["Baumwolle", "Nude"], variants: [{ id: "xs", name: "XS", stock: 15, priceModifier: 0 }, { id: "s", name: "S", stock: 20, priceModifier: 0 }, { id: "m", name: "M", stock: 18, priceModifier: 0 }, { id: "l", name: "L", stock: 12, priceModifier: 0 }, { id: "xl", name: "XL", stock: 8, priceModifier: 0 }], rating: 4.5, reviewsCount: 312, isNew: false, popularity: 85 }
  ],
  BUNDLES: [
    { id: "romantic-night-bundle", name: "Romantic Night Bundle", description: "Luna Lace Set + Midnight Silk Chemise", items: ["luna-lace-set", "midnight-silk-chemise"], discountPercent: 15 },
    { id: "everyday-luxury-bundle", name: "Everyday Luxury Bundle", description: "Rose Petal Bralette + Pure Cotton Essentials", items: ["rose-petal-bralette", "pure-cotton-essentials"], discountPercent: 10 }
  ],
  COUPONS: {
    "WELCOME10": { type: "percent", value: 10, minOrder: 0, maxUses: 1 },
    "LUNA20": { type: "percent", value: 20, minOrder: 100, maxUses: 1 },
    "SHIP0": { type: "freeShipping", value: 0, minOrder: 30, maxUses: 1 }
  }
};
