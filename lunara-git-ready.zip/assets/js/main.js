/**
 * LUNARA Main Application v1.0.1
 */
import { CONFIG } from './config.js';
import { safeStorage, showToast, getProductById, formatCurrency, createElement } from './utils.js';

// State
let cart = safeStorage('cart') || [];
let wishlist = safeStorage('wishlist') || [];
let recentlyViewed = safeStorage('recently_viewed') || [];

// Age Gate
function initAgeGate() {
  const gate = document.getElementById('age-gate');
  if (!gate) return;
  if (safeStorage('age_verified')) { gate.remove(); return; }
  document.body.style.overflow = 'hidden';
  gate.querySelector('.age-gate__confirm')?.addEventListener('click', () => {
    safeStorage('age_verified', true);
    gate.classList.add('age-gate--hidden');
    document.body.style.overflow = '';
    setTimeout(() => gate.remove(), 500);
  });
  gate.querySelector('.age-gate__deny')?.addEventListener('click', () => {
    window.location.href = 'https://google.com';
  });
}

// Theme Toggle
function initTheme() {
  const saved = safeStorage('theme') || 'dark';
  document.documentElement.dataset.theme = saved;
  const btn = document.querySelector('.theme-toggle');
  btn?.addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    safeStorage('theme', next);
  });
}

// Mobile Menu
function initMobileMenu() {
  const toggle = document.querySelector('.menu-toggle');
  const menu = document.getElementById('mobile-menu');
  if (!toggle || !menu) return;
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', !open);
    menu.classList.toggle('mobile-menu--open', !open);
    document.body.style.overflow = open ? '' : 'hidden';
  });
  menu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      menu.classList.remove('mobile-menu--open');
      document.body.style.overflow = '';
    });
  });
}

// Cart Functions
export function addToCart(productId, variantId, qty = 1) {
  const product = getProductById(productId);
  if (!product) return false;
  const variant = product.variants.find(v => v.id === variantId);
  if (!variant || variant.stock < 1) { showToast('Variante nicht verfügbar', 'error'); return false; }
  const existing = cart.find(i => i.productId === productId && i.variantId === variantId);
  if (existing) {
    if (existing.qty + qty > variant.stock) { showToast('Nicht genug auf Lager', 'error'); return false; }
    existing.qty += qty;
  } else {
    cart.push({ productId, variantId, qty, addedAt: Date.now() });
  }
  saveCart();
  showToast(`${product.name} hinzugefügt`, 'success');
  return true;
}

export function removeFromCart(productId, variantId) {
  cart = cart.filter(i => !(i.productId === productId && i.variantId === variantId));
  saveCart();
}

export function updateCartQty(productId, variantId, qty) {
  const item = cart.find(i => i.productId === productId && i.variantId === variantId);
  if (!item) return;
  const product = getProductById(productId);
  const variant = product?.variants.find(v => v.id === variantId);
  if (qty < 1) { removeFromCart(productId, variantId); return; }
  if (variant && qty > variant.stock) { showToast('Nicht genug auf Lager', 'error'); return; }
  item.qty = qty;
  saveCart();
}

export function getCart() { return cart; }
export function clearCart() { cart = []; saveCart(); }

function saveCart() {
  safeStorage('cart', cart);
  updateCartBadge();
  updateShippingProgress();
}

function updateCartBadge() {
  const badge = document.querySelector('.cart-badge');
  if (!badge) return;
  const count = cart.reduce((s, i) => s + i.qty, 0);
  badge.textContent = count;
  badge.hidden = count === 0;
}

// Wishlist Functions
export function toggleWishlist(productId) {
  const idx = wishlist.indexOf(productId);
  if (idx > -1) { wishlist.splice(idx, 1); showToast('Von Wunschliste entfernt', 'info'); }
  else { wishlist.push(productId); showToast('Zur Wunschliste hinzugefügt', 'success'); }
  safeStorage('wishlist', wishlist);
  updateWishlistBadge();
  return wishlist.includes(productId);
}

export function isInWishlist(productId) { return wishlist.includes(productId); }
export function getWishlist() { return wishlist; }

function updateWishlistBadge() {
  const badge = document.querySelector('.wishlist-badge');
  if (!badge) return;
  badge.textContent = wishlist.length;
  badge.hidden = wishlist.length === 0;
}

// Recently Viewed
export function addRecentlyViewed(productId) {
  recentlyViewed = recentlyViewed.filter(id => id !== productId);
  recentlyViewed.unshift(productId);
  if (recentlyViewed.length > CONFIG.MAX_RECENTLY_VIEWED) recentlyViewed.pop();
  safeStorage('recently_viewed', recentlyViewed);
}

export function getRecentlyViewed() { return recentlyViewed; }

// Shipping Progress
function updateShippingProgress() {
  const bar = document.querySelector('.shipping-progress__bar');
  const text = document.querySelector('.shipping-progress__text');
  if (!bar || !text) return;
  const total = cart.reduce((s, i) => {
    const p = getProductById(i.productId);
    return s + (p ? p.price * i.qty : 0);
  }, 0);
  const threshold = CONFIG.FREE_SHIPPING_THRESHOLD;
  const percent = Math.min((total / threshold) * 100, 100);
  bar.style.width = percent + '%';
  if (total >= threshold) text.textContent = '✓ Kostenloser Versand!';
  else text.textContent = `Noch ${formatCurrency(threshold - total)} bis kostenloser Versand`;
}

// Init
document.addEventListener('DOMContentLoaded', () => {
  initAgeGate();
  initTheme();
  initMobileMenu();
  updateCartBadge();
  updateWishlistBadge();
  updateShippingProgress();
});

export { updateShippingProgress };
