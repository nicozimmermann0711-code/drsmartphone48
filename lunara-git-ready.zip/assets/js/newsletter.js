/**
 * LUNARA Newsletter v1.0.1
 */
import { CONFIG } from './config.js';
import { safeStorage, validateEmail, showToast } from './utils.js';

let lastSubmit = 0;

function initNewsletter() {
  const form = document.getElementById('newsletter-form');
  if (!form) return;

  form.addEventListener('submit', async e => {
    e.preventDefault();
    
    // Rate limit
    if (Date.now() - lastSubmit < CONFIG.NEWSLETTER_COOLDOWN) {
      showToast('Bitte warte einen Moment', 'error');
      return;
    }

    // Honeypot
    if (form.querySelector('[name="website"]')?.value) return;

    const email = form.querySelector('[name="email"]').value;
    const consent = form.querySelector('[name="consent"]')?.checked;

    if (!validateEmail(email)) { showToast('Bitte gültige E-Mail eingeben', 'error'); return; }
    if (!consent) { showToast('Bitte Einwilligung bestätigen', 'error'); return; }

    lastSubmit = Date.now();

    // If provider configured, submit
    if (CONFIG.NEWSLETTER_PROVIDER) {
      try {
        await fetch(CONFIG.NEWSLETTER_PROVIDER, {
          method: 'POST',
          mode: 'no-cors',
          body: new FormData(form)
        });
      } catch {}
    }

    // Show success
    safeStorage('newsletter_subscribed', true);
    form.innerHTML = '<div class="newsletter-success"><span class="newsletter-success__icon">✓</span><p>Danke für deine Anmeldung!</p></div>';
    showToast('Newsletter-Anmeldung erfolgreich!', 'success');
  });

  // Already subscribed
  if (safeStorage('newsletter_subscribed')) {
    form.innerHTML = '<div class="newsletter-success"><span class="newsletter-success__icon">✓</span><p>Du bist bereits angemeldet!</p></div>';
  }
}

document.addEventListener('DOMContentLoaded', initNewsletter);
